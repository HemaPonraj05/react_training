import React from "react";

class EmployeeList extends React.Component {
  render() {
    return (
      <div>
        <h1>Employees</h1>
      </div>
    );
  }
}

export default EmployeeList;
