import React from "react";

class Header extends React.Component {
  render() {
    return (
      <header class="header">
        <h1>Employee Database</h1>
      </header>
    );
  }
}

export default Header;
